#include"vehicle.h"
#pragma once

class Bike : public Vehicle
{
protected:
	double height;
	bool selfstart;
	bool discBrake;
	int no_of_bikes;
	int no_wheels;
public:
	Bike(double height = 0, bool selfstart = true, bool discbrakes = true);
	//void copy(); to be done
	void setheight(double height);
	void setselfstart(bool opt);
	void setdiscbrake(bool opt);
	void setnoofbike(int no_of_bikes);
	double getheight();
	bool getselfstart();
	bool getdiscbrake();
	int getnoofbikes();
	char checktype();
	void display();
	//void operator =(Bike &obj);
	//istream& operator >>(istream& in);
};