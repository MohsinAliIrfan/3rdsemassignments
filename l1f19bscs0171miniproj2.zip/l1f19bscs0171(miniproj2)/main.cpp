#include "bilalmotors.h"
int main() {
	Bilal_Motors bm;
	if (bm.menu() == 0)
		return 0;
}