#include "vehicle.h"
#include "bike.h"
#include "car.h"
#include "truck.h"
#include "bilalmotors.h"
#include"fstream"

// Vehicle
void Vehicle::setcompanyname(char* name) {

	if (com_name != nullptr)
		delete[]com_name;
	
	com_name = new char[strlen(name) + 1];
	strcpy_s(com_name, strlen(name) + 1, name);
}
void Vehicle::setclor(char* color) {

	if (this->color != nullptr)
		delete[]this->color;
	
	this->color = new char[strlen(color) + 1];
	strcpy_s(this->color, strlen(color) + 1, color);
}
void Vehicle::setcc(int cc) {

	if (cc < 0)
		this->cc = 70;
	else
		this->cc = cc;
}
void Vehicle::setnowheels(int wheels) {

	if (wheels < 2)
		this->no_wheels = 2;
	else
		this->no_wheels = wheels;
}
void Vehicle::settype(char *type) {

	cout << type;
	if (this->type)
		delete[]this->type;
	
	this->type = new char[strlen(type) + 1];
	strcpy_s(this->type, strlen(type) + 1, type);
	cout << this->type;
}
char* Vehicle::gettype() {

	char* newarr = new char[strlen(type) + 1];
	strcpy_s(newarr, strlen(type) + 1, type);
	return newarr;
}
char* Vehicle::getcompanyname() {

	char* newarr = new char[strlen(com_name) + 1];
	strcpy_s(newarr, strlen(com_name) + 1, com_name);
	return newarr;
}
char* Vehicle::getcolor() {

	char* newarr = new char[strlen(color) + 1];
	strcpy_s(newarr, strlen(color) + 1, color);
	return newarr;
}
char Vehicle::checktype() { return 'a'; }
int Vehicle::getcc() { return cc; }
int Vehicle::getnoofwheels() { return no_wheels; }
void Vehicle::display() {	

	cout << "\n TYPE: " << type;
	cout << "\n COMPANY NAME: " << com_name;
	cout << "\n COLOR: " << color;
	cout << "\n CC: " << cc;
	cout << "\n NUMBER OF WHEELS: " << no_wheels;
}
Vehicle::~Vehicle() {

	if (com_name)
		delete[]com_name;
	if (color)
		delete[]color;
}

//Bike
Bike::Bike(double heigt, bool slefstart, bool discbrakes): height(heigt), selfstart(slefstart), 
discBrake(discbrakes) {}

void Bike::setheight(double height) {
	
	if (height <= 0)
		this->height = 1;
	else 
		this->height = height;
}
void Bike::setnoofbike(int no_of_bikes) {

	if (no_of_bikes <= 0)
	    this->no_of_bikes = 1;
	else 
		this->no_of_bikes = no_of_bikes;
}
void Bike::setselfstart(bool opt) { this->selfstart = selfstart; }
void Bike::setdiscbrake(bool opt) { this->discBrake = discBrake; }
double Bike::getheight() { return height; }
int Bike::getnoofbikes() { return no_of_bikes; }
bool Bike::getselfstart() { return selfstart; }
bool Bike::getdiscbrake() { return discBrake; }
char Bike::checktype() { return 'b'; }

void Bike::display() {

	Vehicle::display();
	cout << "\n HEIGHT: " << height;
	if (selfstart) cout << "\n SELF START ";
	else cout << "\n NOT SELF START ";
	if (discBrake) cout << "\n DISC BRAKE ";
	else cout << "\n NOT DISC BRAKE ";
	cout << endl;
}
// Car
Car::Car(int noofdoors, int noofseats, char* transmision): no_of_doors(noofdoors), no_of_seats(noofseats),transmission(transmision){}
void Car::setnoofcars(int no_of_cars) {
	
	if (no_of_cars <= 0)
		this->no_of_cars = 1;
	else
		this->no_of_cars = no_of_cars;
}
void Car::setnoofdoors(int no_of_doors) {
	
	if (no_of_doors < 4 || no_of_doors> 6 || no_of_doors == 5)
		this->no_of_doors = 4;
	else
		this->no_of_doors = no_of_doors;
}
void Car::setnoofseats(int no_of_seats) {

	if (no_of_seats < 4 || no_of_seats> 7)
		this->no_of_seats = no_of_seats;
	else
		this->no_of_seats = no_of_seats;
}
void Car::settransmission(char *tra) {
	
	if (this->transmission)
		delete[]this->transmission;

	this->transmission = new char[strlen(tra) + 1];
	strcpy_s(this->transmission, strlen(tra) + 1, tra);
}
char* Car::gettransmission() {

	char* newarr = new char[strlen(this->transmission) + 1];
	strcpy_s(newarr, strlen(this->transmission) + 1, this->transmission);
	return newarr;
}
int Car::getnoofcars() { return this->no_of_cars; }
int Car::getnoofdoors() { return this->no_of_doors; }
int Car::getnoofseats() { return this->no_of_seats; }
char Car::checktype() { return 'c'; }

void Car::display() {

	cout << "\n NUMBER OF DOORS: " << no_of_doors;
	cout << "\n NUMBER OF SEATS: " << no_of_seats;
	cout << "\n TRANSMISSION: " << transmission;
	cout << endl;
}

//truck

Truck::Truck(double size, char* ptr, bool fourwheeldrive, int num) : container_size(size), category(ptr),
four_wheel_drive(fourwheeldrive), no_of_trucks(num) {};
void Truck::setcontainersize(double size) {

	if (size <= 0)
		this->container_size = 1;
	else
	   this->container_size = size;
}
void Truck::setcategory(char *ptr) {

	if (this->category)
		delete[]this->category;
	
	this->category = new char[strlen(ptr) + 1];
	strcpy_s(this->category, strlen(ptr) + 1, ptr);
}
void Truck::setnooftruks(int num) {

	if (num <= 0)
		this->no_of_trucks = 1;
	else
		this->no_of_trucks = num;
}
void Truck::setfourwheeldrive(bool check) { this->four_wheel_drive = check; }

char* Truck::getcategory() {

	char* newarr = new char[strlen(this->category) + 1];
	strcpy_s(newarr, strlen(this->category) + 1, this->category);
	return newarr;
}
double Truck::getcontainersize() { return this->container_size; }
bool Truck::getfourwheeldrive() { return this->four_wheel_drive; }
int Truck::getnooftrucks() { return no_of_trucks; }
char Truck::checktype() { return 't'; }

void Truck::display() {

	Vehicle::display();
	cout << "\n CONTAINER SIZE: " << container_size;
	cout << " CATEGORY: " << category;
	if (four_wheel_drive) cout << "\n 4 WHEEL DRIVE ";
	else cout << "\n NOT 4 WHEEL DRIVE ";
	cout << endl;			
}
//BILAL_MOTORS

Bilal_Motors::Bilal_Motors() {
	//arr = nullptr;
	count = 0;
	arr = new Vehicle * [count];
}
void Bilal_Motors::add_vehicle(Vehicle *p) {

	arr[count] = p;
	//arr = regrow(arr, count ,p);
	++count ;
}
void Bilal_Motors::search_vehicle(char p) {

	bool check = true;
	char ch;
	for (int i = 0; i < count; i++) 
		if (arr[i]->checktype() == p) {
			cout << endl;
        	  arr[i]->display();
			  check = true;
		}
	if (!check)
		cout << "\n\n\n         NO RECORD FOUND!!!! ";
}

bool Bilal_Motors::saveData(char*name) {

	int b = 0, c = 0, t = 0;

	int size = strlen(name);

	name[size++] = '.';
	name[size++] = 't';
	name[size++] = 'x';
	name[size++] = 't';
	name[size] = '\0';

	cout << "\n name " << name;
	ofstream write(name);
//{
		for (int i = 0; i < count; i++) {
			if (arr[i]->checktype() == 'b') ++b;
			else if (arr[i]->checktype() == 'c') ++c;
			else if (arr[i]->checktype() == 't') ++t;
		}
		write << b << endl;
		write << c << endl;
		write << t << endl;
		
		for (int i = 0; i < count; i++) {
			if (arr[i]->checktype() == 'b') {
				write << arr[i]->getcompanyname() << " ";
				write << arr[i]->gettype() << " ";	
				write << arr[i]->getcolor() << " ";
				write << arr[i]->getcc();;
			}
		}
		write << endl;
		for (int i = 0; i < count; i++) {
			if (arr[i]->checktype() == 'c') {
				write << arr[i]->getcompanyname() << " ";
				write << arr[i]->gettype() << " "; //to be made
				write << arr[i]->getcolor() << " ";
				write << arr[i]->getcc();;
			}
		}
		write << endl;
		for (int i = 0; i < count; i++) {
			if (arr[i]->checktype() == 't') {
				write << arr[i]->getcompanyname() << " ";
				write << arr[i]->gettype() << " "; //to be made
				write << arr[i]->getcolor() << " ";
				write << arr[i]->getcc();;
			}
		}
		write.close();
 //}
		return true;
}

int Bilal_Motors::menu() {

	char* com_name = new char[20];
	char* color = new char[20];
	int no_wheels, cc;
	Bilal_Motors b;
	char opt;

	cout << "\n*************************                         ******************************";
	cout << "\n                          WELCOME TO BILAL MOTORS                               ";
	cout << "\n*************************                         ******************************";
	cout << "\n\n MENU: ";
	cout << "\n\n 'S'   SHOW VEHICLE LIST: ";
	cout << "\n 'E'   CREATE A DATA FILE: ";
	cout << "\n 'A'   ADD NEW VEHCILES: ";
	cout << "\n 'F'   FIND VEHICLE BYE TYPE: ";
	cout << "\n 'Q'   QUIT PROGRAM:" << endl;
	cin >> opt;
    while(true){
	if (opt == 'S');
	else if (opt == 'E') {
		char* arr = new char[50];
		cout << "\n\n ENTER FILE NAME: "; cin >> arr;
		b.saveData(arr);
		delete[]arr;
	}
	else if (opt == 'A')
	{
		while (true) {

			cout << "\n         'B'      BIKE:";
			cout << "\n         'C'      CAR:";
			cout << "\n         'T'      TRUCK: ";
			cin >> opt;
			if (opt == 'B') {
				char arr[5] = { 'b','i','k','e','\0'};
				double height = 0;
				bool diskbrake;
				bool selfstart;
				int no_of_wheels = 0;

				cout << "\n\n ENTER COMPNAY NAME: "; cin >> com_name;
				cout << "\n ENTER COLOR: "; cin >> color;
				cout << "\n ENTER CC: "; cin >> cc;
				cout << "\n ENTER HEIGHT: "; cin >> height;
				cout << "\n ENTER NUMBER OF WHEELS: "; cin >> no_of_wheels;

				cout << "\n ENTER 'Y' IF DISC BRAKE 'N' IF NOT: "; cin >> opt;
				if (opt == 'Y')	diskbrake = true;
				else diskbrake = false;

				cout << "\n ENTER 'Y' IF SELF START 'N' IF NOT: "; cin >> opt;
				if (opt == 'Y')	selfstart = true;
				else selfstart = false;

				Bike* bike = new Bike(height, selfstart, diskbrake);
				bike->setcompanyname(com_name);
				bike->setclor(color);
				bike->setcc(cc);
				bike->settype(arr);
				bike->setnowheels(no_of_wheels);
				b.add_vehicle(bike);
			}
			else if (opt == 'C') {
				char arr[4] = { 'c','a','r','\0'};
				int no_of_doors;
				char* transmission = new char[20];
				int no_of_seats;

				cout << "\n\n ENTER COMPNAY NAME: "; cin >> com_name;
				cout << "\n ENTER COLOR: "; cin >> color;
				cout << "\n ENTER CC: "; cin >> cc;
				cout << "\n\n ENTER NUMBER OF DOORS: "; cin >> no_of_doors;
				cout << "\n ENTER NUMBER OF NUMBER OF SEATS: "; cin >> no_of_seats;
				cout << "\n ENTER TRANSMISSION: "; cin >> transmission;
				cout << "\n ENTER NUMBER OF WHEELS: "; cin >> no_wheels;

				Car* car = new Car(no_of_doors, no_of_seats, transmission);
				b.add_vehicle(car);
				car->setcompanyname(com_name);
				car->setclor(color);
				car->setcc(cc);
				car->setnowheels(no_wheels);
				car->settype(arr);
			}
			else if (opt == 'T') {
				char arr[6] = { 't','r','u','c' ,'k','\0' };
				double container_size;
				char* category = new char[20];
				bool four_wheel_drive;
				int no_of_trucks;

				cout << "\n\n ENTER COMPNAY NAME: "; cin >> com_name;
				cout << "\n ENTER COLOR: "; cin >> color;
				cout << "\n ENTER CC: "; cin >> cc;
				cout << "\n ENTER CONTAINER SIZE: "; cin >> container_size;
				cout << "\n ENTER CATEGORY: "; cin >> category;
				cout << "\n ENTER NUMBER OF WHEELS: "; cin >> no_wheels;

				cout << "\n ENTER 'Y' FOR 4 WHEEL DRIVE, 'N' IF NOT: "; cin >> opt;
				if (opt == 'Y') four_wheel_drive = true;
				else four_wheel_drive = false;

				Truck* truck = new Truck(container_size, category, four_wheel_drive);
				b.add_vehicle(truck);
				truck->setcompanyname(com_name);
				truck->setclor(color);
				truck->setcc(cc);
				truck->setnowheels(no_wheels);
				truck->settype(arr);
			}
			cout << "\n FOR ENTERING MORE DATA PRESS 'Y' or 'y' ELSE PRESS 'N' OR 'n' "; cin >> opt;
			if (opt == 'N' || opt == 'n')
				break;
		}
	}
	else if (opt == 'F') {
		cout << "\n PRESS: ";
		cout << "\n\n   'b' FOR  BIKE ";
		cout << "\n   'c'  FOR CAR ";
		cout << "\n   't'  FOR TRUCK";
		cout << "\n ENTER YOUR OPTION: "; cin >> opt;
		b.search_vehicle(opt);
	}
	else if(opt == 'Q')
	return 0;
	cout << "\n ENTER OPTION: "; cin >> opt;
   }

}
