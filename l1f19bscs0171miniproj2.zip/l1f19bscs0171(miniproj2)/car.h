#include "vehicle.h"
#pragma once

class Car : public Vehicle
{
	int no_of_doors;
	char* transmission = new char[20];
	int no_of_seats, no_of_cars;
public:
	Car(int noofdoors = 0, int noofseats = 0 ,char *transmission = nullptr);
	//void copy(); no_of_doors, no_of_seats, no_wheels, transmission
	void setnoofdoors(int no_of_doors);
	void setnoofseats(int no_of_seats);
	void setnoofcars(int no_of_cars);
	void settransmission(char *tra);
	int getnoofdoors();
	int getnoofseats();
	int getnoofcars();
	char* gettransmission();
	char checktype();
	void display();
	//void operator =(Car& obj);
	//istream& operator >>(istream& in);
};