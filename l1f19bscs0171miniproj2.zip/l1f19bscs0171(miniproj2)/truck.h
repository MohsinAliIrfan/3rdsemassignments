#include"vehicle.h"
#pragma once

class Truck: public Vehicle
{
	int no_wheels;
	double container_size;
	char* category = new char[20];
	bool four_wheel_drive;
	 int no_of_trucks;
public:
	Truck(double size = 0, char* ptr = 0, bool four_wheel_drive = true, int num = 0);
	void setcontainersize(double size);
	void setcategory(char* ptr);
	void setfourwheeldrive(bool check);
	void setnooftruks(int num);
	double getcontainersize();
	char* getcategory();
	bool getfourwheeldrive();
	 int getnooftrucks();
	 char checktype();
	 void display();
	//void operator =(Truck& obj);
	//istream& operator >>(istream& in);
};