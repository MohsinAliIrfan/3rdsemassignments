#pragma once
#include<iostream>
using namespace std;

class Vehicle 
{
	char* com_name = new char[20];
	char* color = new char[20];
	int no_wheels, cc;
	char* type = new char[20];
public:
	virtual char checktype() = 0;
	virtual void display();
	void setcompanyname(char *name);
	void setclor(char *color);
	void setnowheels(int wheels);
	void setcc(int cc);
	void settype(char* type);
	char* gettype();
	char* getcompanyname();
	char* getcolor();
	int getnoofwheels();
	int getcc();
	//char* gettype();
	~Vehicle();
};