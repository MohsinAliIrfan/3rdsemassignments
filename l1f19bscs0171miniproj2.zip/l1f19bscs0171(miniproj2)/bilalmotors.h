#include "vehicle.h"
#include "bike.h"
#include "car.h"
#include "truck.h"

class Bilal_Motors {
	Vehicle** arr;
	int count;
public:
	Bilal_Motors();
	void add_vehicle(Vehicle *p);
	void search_vehicle(char p);
	//~Bilal_Motors();
	int menu();
	bool saveData(char* fileName);
};